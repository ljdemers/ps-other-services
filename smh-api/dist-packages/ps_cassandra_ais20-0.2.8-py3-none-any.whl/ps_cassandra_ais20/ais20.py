"""
Data access module for the ais20 schema
"""
import datetime
import json
import os
from typing import Dict, List, Optional, Set, Tuple

import statsd
from cassandra.query import BatchStatement

from ps_cassandra_ais20.utils import date
from ps_cassandra_ais20.utils.log_manager import logger


class CassandraQuery:
    session = None
    statements = {}
    stats = None

    def __init__(self, session):
        self.session = session

        # create the stats client for managing statistics
        self.stats = statsd.StatsClient(
            host=os.environ.get("STATSD_HOST"),
            port=int(os.environ.get("STATSD_PORT")),
            prefix=os.environ.get("STATSD_PREFIX"),
        )

    def _prepare_statement(self, name: str) -> str:
        """Prepare the named statement"""
        self.stats.incr("cassandra.query.prepare_statement")
        try:
            query = getattr(self, name)()
            stmt = self.session.prepare(query)
        except AttributeError:
            raise AttributeError(name)
        return stmt


class AIS20Reader(CassandraQuery):
    """
    Manage read from the AIS schema
    """

    def _select_position_by_mmsi_timestamp(self):

        return (
            "select * from ais20.position_by_mmsi_timestamp where "
            + "mmsi = ? and timestamp < ? and timestamp > 0 "
            + "order by timestamp desc limit ?"
        )

    def _select_position_by_mmsi_start_end_timestamp(self):
        return (
            "select * from ais20.position_by_mmsi_timestamp where "
            + "mmsi = ? and timestamp > ? and timestamp < ? "
            + "order by timestamp desc limit ?"
        )

    def _select_ship(self):
        return "select * from ais20.ship2 where mmsi = ?"

    def _select_latest_static(self):
        return (
            "select * from ais20.static_by_mmsi_hourly where "
            + "mmsi = ? and timestamp > ? "
            + "order by timestamp desc limit 1"
        )

    def _select_latest_voyage(self):
        return (
            "select * from ais20.voyage_by_mmsi_hourly where "
            + "mmsi = ? and timestamp > ? "
            + "order by timestamp desc limit 1"
        )

    def _select_subscription(self):
        return "select * from ais20.subscription where mmsi = ?"

    def _select_subscription_mmsis(self):
        return "select mmsi from ais20.subscription"

    def _select_subscriptions(self):
        return "select * from ais20.subscription"

    def _timestamp_from_age(self, age_in_days: int) -> int:
        """
        Create a datetime used to filter data from an age parameter.

        :param age_in_days: the number of days to subtract from the
        current time.
        """
        dt = datetime.datetime.utcnow()
        dt = dt - datetime.timedelta(days=age_in_days)
        return int(dt.timestamp())

    def get_statement(self, name: str) -> str:
        stmt = self.statements.get(name)
        if not stmt:
            stmt = self._prepare_statement(name)
            self.statements[name] = stmt
        return stmt

    def get_track(
        self,
        mmsi: int,
        end_date: datetime.datetime,
        position_count: int,
        start_date: Optional[datetime.datetime] = None,
    ):
        """
        Get the trail of positions for the MMSI

        :param mmsi: the MMSI of the vessel to track
        :param end_date: datetime indicating when the latest position should be
        :param position_count: integer count of positions to return
        :param start_date: datetime indicating when the first position should be
        """

        with self.stats.timer("ais20reader.get_track.elapsed"):
            if start_date:
                stmt = self.get_statement(
                    "_select_position_by_mmsi_start_end_timestamp"
                )
                start_ts = date.datetime2timestamp(start_date)
                end_ts = date.datetime2timestamp(end_date)
                bound = stmt.bind([mmsi, start_ts, end_ts, position_count])
            else:
                stmt = self.get_statement("_select_position_by_mmsi_timestamp")
                end_ts = date.datetime2timestamp(end_date)
                bound = stmt.bind([mmsi, end_ts, position_count])
            return self.session.execute(bound)

    def get_ship(self, mmsi: int) -> List[int]:
        """
        Get the ship for the MMSI

        convenience method to get a single ship

        :param mmsi: the MMSI of the vessel
        """
        return self.get_ships([mmsi])

    def get_ships(self, mmsis: List[int]):
        with self.stats.timer("ais20reader.get_ships.elapsed"):
            stmt = self.get_statement("_select_ship")
            bound = stmt.bind(mmsis)
            return self.session.execute(bound)

    def get_latest_static(self, mmsi: int, max_static_age: int):
        """
        Get the static data for the MMSI

        :param mmsi: the MMSI of the vessel
        :param max_static_age: the maximum age of static data to return
        """
        with self.stats.timer("ais20reader.get_latest_static.elapsed"):
            ts_limit = self._timestamp_from_age(max_static_age)
            stmt = self.get_statement("_select_latest_static")
            bound = stmt.bind([mmsi, ts_limit])
            return self.session.execute(bound)

    def get_latest_voyage(self, mmsi: int, max_voyage_age: int):
        """
        Get the voyage data for the MMSI

        :param mmsi: the MMSI of the vessel
        :param max_voyage_age: the maximum age of voyage data to return
        """
        with self.stats.timer("ais20reader.get_latest_voyage.elapsed"):
            ts_limit = self._timestamp_from_age(max_voyage_age)
            stmt = self.get_statement("_select_latest_voyage")
            bound = stmt.bind([mmsi, ts_limit])
            return self.session.execute(bound)

    def get_subscription(self, mmsi: int):
        """
        Get the subscription info for the MMSI
        """
        with self.stats.timer("ais20reader.get_subscription.elapsed"):
            stmt = self.get_statement("_select_subscription")
            bound = stmt.bind([mmsi])
            return self.session.execute(bound)

    def get_subscription_mmsis(self):
        with self.stats.timer("ais20reader.get_subscription_mmsis.elapsed"):
            stmt = self.get_statement("_select_subscription_mmsis")
            return self.session.execute(stmt)

    def get_subscriptions(self):
        with self.stats.timer("ais20reader.get_subscriptions.elapsed"):
            stmt = self.get_statement("_select_subscriptions")
            return self.session.execute(stmt)


class AIS20Writer(CassandraQuery):
    """
    Manage writes to the AIS 2.0 schema
    """

    #
    # static_by_mmsi_hourly
    #
    def _insert_static_by_mmsi_hourly(self):
        return (
            "insert into ais20.static_by_mmsi_hourly("
            + "mmsi, timestamp, call_sign, dimensions, equipment_type,"
            + "imo_num, loa, name, ship_type) values (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )

    def _static_by_mmsi_hourly_fields(
        self, mmsi: int, hour_timestamp: int, rec: Dict
    ) -> Tuple:
        """return a tuple of the fields to insert into
        static_by_mmsi_hourly

            mmsi
            hour timestamp
            callsign
            dimensions
            equipment type
            imo_num
            loa
            name
            ship type
        """
        return (
            mmsi,
            hour_timestamp,
            rec.get("callsign"),
            self._dimensions(rec),
            rec.get("epfd"),
            self._null_int(rec, "imo_id"),
            self._null_int(rec, "loa"),
            rec.get("shipname"),
            rec.get("shiptype"),
        )

    #
    # voyage_by_mmsi_hourly
    #
    def _insert_voyage_by_mmsi_hourly(self):
        return (
            "insert into ais20.voyage_by_mmsi_hourly "
            + "(mmsi, timestamp, cargo_type, destination, draught, eta)"
            + "values (?, ?, ?, ?, ?, ?)"
        )

    def _voyage_by_mmsi_hourly_fields(
        self, mmsi: int, hour_timestamp: int, rec: Dict
    ) -> Tuple:
        """ return a tuple of the fields to insert into
        voyage_by_mmsi_hourly

            mmsi
            timestamp
            cargo_type
            destination
            draught
            eta
        """
        eta = rec.get("eta")
        if eta:
            eta = int(eta.timestamp())

        return (
            mmsi,
            hour_timestamp,
            None,
            rec.get("destination"),
            self._null_float(rec, "draught"),
            eta,
        )

    #
    # ship_by_imo_num
    #
    def _insert_ship_by_imo_num(self):
        return "insert into ais20.ship_by_imo_num(imo_num, mmsi) " + "values (?, ?)"

    def _ship_by_imo_num_fields(self, mmsi: int, rec: Dict) -> Tuple[int, Set[int]]:
        """return a tuple of fields to insert into ship_by_imo_num

            imo_num
            mmsi
        """
        try:
            return (int(rec.get("imo_id")), set([mmsi]))
        except (TypeError, ValueError):
            return None

    #
    # ship_by_name
    #
    def _insert_ship_by_name(self):
        return "insert into ais20.ship_by_name(name, mmsi) values (?, ?)"

    def _ship_by_name_fields(self, mmsi: int, rec: Dict) -> Tuple[int, Set[int]]:
        """return a tuple of the fields to insert into
        ship_by_name

            name
            mmsi
        """
        name = rec.get("shipname")
        if name:
            return (name, set([mmsi]))

    #
    # ship
    #
    def _insert_ship(self):
        return (
            "INSERT INTO ais20.ship2 (mmsi, call_sign, imo_number, loa, "
            + "name, position, position_course, position_speed, "
            + "position_timestamp, ship_type, voyage_destination, "
            + "voyage_eta, voyage_timestamp, status) VALUES "
            + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"
        )

    def _ship_fields(self, rec: Dict) -> Tuple:
        return (
            rec["mmsi"],
            rec.get("call_sign"),
            self._null_int(rec, "imo_number"),
            self._null_int(rec, "loa"),
            rec.get("name"),
            rec.get("position"),
            self._null_float(rec, "position_course"),
            self._null_float(rec, "position_speed"),
            self._null_int(rec, "position_timestamp"),
            rec.get("ship_type"),
            rec.get("voyage_destination"),
            self._null_int(rec, "voyage_eta"),
            self._null_int(rec, "voyage_timestamp"),
            rec.get("status"),
        )

    #
    # position_by_mmsi_timestamp
    #
    def _insert_position_by_mmsi_timestamp(self):
        return (
            "insert into position_by_mmsi_timestamp (mmsi, timestamp,"
            + " extdata, latitude, longitude, course, speed, heading,"
            + " status, source, channel) values "
            + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )

    @staticmethod
    def get_source(source: str) -> str:
        """
        Map data source to a short mnemonic for storage / presentation

        OT, OS, IT, SS (orbcomm terrestrial, orbcomm satellite, ihs
        terrestrial, spire satellite)
        """
        return {
            "OrbcommSatellite": "OS",
            "OrbcommTerrestrial": "OT",
            "SpireSatellite": "SS",
            "IHSTerrestrial": "IT",
        }.get(source, source)

    def _position_by_mmsi_timestamp_fields(self, mmsi: int, rec: Dict) -> Tuple:
        """return a tuple of the fields to insert into
        position_by_mmsi_timestamp:

            mmsi
            timestamp
            extdata
            latitude
            longitude
            course
            speed
            heading
            status
            source
            channel

            Throws ValueError if latitude, longitude, and timestamp are not
            present or the correct type.
        """
        source = self.get_source(rec.get("source"))

        # channel is either A or B; assume B if we don't know
        channel = rec.get("channel")
        if channel == "":
            channel = None
        if channel:
            assert len(channel) == 1, "invalid channel value"

        return (
            mmsi,
            int(rec["msg_timestamp"]),
            self._position_extdata(rec),
            float(rec["lat"]),
            float(rec["lon"]),
            self._null_float(rec, "course"),
            self._null_float(rec, "speed"),
            self._null_float(rec, "heading"),
            rec.get("status"),
            source,
            channel,
        )

    #
    # archive
    #
    def _insert_archive_orbcomm(self):
        return (
            "insert into ais20.archive_orbcomm (archive_date, "
            + "timestamp, sentences) values (?, ?, ?)"
        )

    def _insert_archive_spire(self):
        return (
            "insert into ais20.archive_spire (archive_date, "
            + "timestamp, sentences) values (?, ?, ?)"
        )

    def _insert_archive_ihs(self):
        return (
            "insert into ais20.archive_ihs (archive_date, "
            + "timestamp, sentences) values (?, ?, ?)"
        )

    #
    # subscription
    #
    def _insert_subscription(self):
        return (
            "insert into ais20.subscription (mmsi, "
            + "last_delivered_timestamp, reporting_interval_seconds, "
            + "queue) values (?, ?, ?, ?)"
        )

    def _delete_subscription(self):
        return "delete from ais20.subscription where mmsi = ?"

    def _subscription_fields(self, rec: Dict) -> Tuple:
        last_delivered_timestamp = rec.get("last_delivered_timestamp")
        if last_delivered_timestamp is None:
            timestamp = 0
        elif isinstance(last_delivered_timestamp, int):
            timestamp = last_delivered_timestamp
        elif isinstance(last_delivered_timestamp, str):
            timestamp = date.str2timestamp(last_delivered_timestamp)

        return (
            rec["mmsi"],
            timestamp,
            int(rec["reporting_interval_seconds"]),
            rec["queue"],
        )

    def delete_subscription(self, mmsi: int):
        """
        Delete the subscription
        :param mmsi: The mmsi to delete the subscription for
        """
        with self.stats.timer("ais20writer.delete_subscription.elapsed"):
            prepared = self.delete_statement("subscription")
            stmt = prepared.bind([mmsi])
            self.session.execute(stmt)

    @staticmethod
    def _null_int(rec: Dict, key: str) -> int:
        """return the value as an int or None"""
        val = rec.get(key)
        return AIS20Writer._null_int_val(val)

    @staticmethod
    def _null_int_val(val: str) -> int:
        """return the value as an int or None"""
        if val is not None:
            return int(val)

    @staticmethod
    def _null_float(rec: Dict, key: str) -> float:
        """return the value as a float or None"""
        val = rec.get(key)
        if val is not None:
            return float(val)

    def _position_extdata(self, rec: Dict) -> str:
        """Create a dictionary of extra fields/metadata"""
        extdata = {"msgtype": rec.get("msgtype")}
        return json.dumps(extdata)

    def _hour_timestamp(self, timestamp: datetime.datetime) -> int:
        """get an integer representation of the beginning of the hour
        from the timestamp by concatenating the year, month, day, hour"""
        ts_date = datetime.datetime.utcfromtimestamp(timestamp)
        return int(ts_date.strftime("%Y%m%d%H"))

    # DTO for the Dimensions UDT
    class Dimensions(object):
        to_bow = None
        to_stern = None
        to_port = None
        to_starboard = None

        def __init__(self, to_bow, to_stern, to_port, to_starboard):
            self.to_bow = to_bow
            self.to_stern = to_stern
            self.to_port = to_port
            self.to_starboard = to_starboard

    @staticmethod
    def _dimensions(rec: Dict):
        # apparently there are some differences about how to spell starboard
        stb = None
        if "to_starbord" in rec:
            stb = rec["to_starbord"]
        if "to_starboard" in rec:
            stb = rec["to_starboard"]
        return AIS20Writer.Dimensions(
            AIS20Writer._null_int(rec, "to_bow"),
            AIS20Writer._null_int(rec, "to_stern"),
            AIS20Writer._null_int(rec, "to_port"),
            AIS20Writer._null_int_val(stb),
        )

    def insert_statement(self, name: str) -> str:
        name = "_insert_" + name
        stmt = self.statements.get(name)
        if not stmt:
            stmt = self._prepare_statement(name)
            self.statements[name] = stmt
        return stmt

    def delete_statement(self, name: str) -> str:
        name = "_delete_" + name
        stmt = self.statements.get(name)
        if not stmt:
            stmt = self._prepare_statement(name)
            self.statements[name] = stmt
        return stmt

    def batch_insert(
        self, batch: BatchStatement, name: str, data: Tuple[int, Set[int]]
    ) -> BatchStatement:
        stmt = self.insert_statement(name)
        batch.add(stmt, data)

    def write_ship(self, ship: Dict):
        """
        Write the ship record
        :param ship: the ship record to write
        """
        with self.stats.timer("ais20writer.write_ship.elapsed"):
            prepared = self.insert_statement("ship")
            fields = self._ship_fields(ship)
            stmt = prepared.bind(fields)
            self.session.execute(stmt)

    def write_subscription(self, subscription: Dict):
        """
        Write the subscription
        :param subscription: the subscription object to write
        """
        with self.stats.timer("ais20writer.write_subscription.elapsed"):
            prepared = self.insert_statement("subscription")
            stmt = prepared.bind(self._subscription_fields(subscription))
            self.session.execute(stmt)

    def write_sav_record(self, rec: Dict) -> bool:
        """
        Write a static and voyage record to its various materializations:
            ship_by_name
            ship_by_imo_num
            ship
            static_by_mmsi_hourly
            voyage_by_mmsi_hourly

        writes are batched to ensure consistent data
        """
        with self.stats.timer("ais20writer.write_sav_record.elapsed"):
            if rec["source"] == "SPIRE-S":
                return False

            batch = BatchStatement()
            mmsi = int(rec.get("mmsi"))
            hour_timestamp = self._hour_timestamp(rec.get("msg_timestamp"))

            ship_by_name_fields = self._ship_by_name_fields(mmsi, rec)
            if ship_by_name_fields:
                self.batch_insert(batch, "ship_by_name", ship_by_name_fields)

            ship_by_imo_num_fields = self._ship_by_imo_num_fields(mmsi, rec)
            if ship_by_imo_num_fields:
                self.batch_insert(batch, "ship_by_imo_num", ship_by_imo_num_fields)

            static_by_mmsi_hourly_fields = self._static_by_mmsi_hourly_fields(
                mmsi, hour_timestamp, rec
            )
            logger.logger.debug(
                f"static_by_mmsi_hourly_fields {static_by_mmsi_hourly_fields}"
            )
            self.batch_insert(
                batch, "static_by_mmsi_hourly", static_by_mmsi_hourly_fields
            )
            self.batch_insert(
                batch,
                "voyage_by_mmsi_hourly",
                self._voyage_by_mmsi_hourly_fields(mmsi, hour_timestamp, rec),
            )
            self.session.execute(batch)
            return True

    def write_position_report(self, rec: Dict) -> bool:
        """
        Write a position report message and its various materializations
            ship
            position_by_mmsi_timestamp

        writes are batched to ensure consistent data
        """
        with self.stats.timer("ais20writer.write_position_report.elapsed"):
            if rec["source"] == "SPIRE-S":
                return False

            if "lat" not in rec or "lon" not in rec:
                logger.logger.debug(f"no lat, lon in position: {rec}")
                return False
            batch = BatchStatement()
            mmsi = int(rec.get("mmsi"))
            self.batch_insert(
                batch,
                "position_by_mmsi_timestamp",
                self._position_by_mmsi_timestamp_fields(mmsi, rec),
            )
            self.session.execute(batch)
            return True
