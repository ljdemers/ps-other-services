import sys

import boto3

LOCAL_TOOLS_PROFILE = "polestar-tools"
CODEARTIFACT_DOMAIN = "polestar-tools"
TOOLS_ACCOUNT = "324252367609"


def have_local_profile():
    for profile in boto3.session.Session().available_profiles:
        if profile == LOCAL_TOOLS_PROFILE:
            return True
    return False


def get_session():
    args = {}
    if have_local_profile():
        args["profile_name"] = LOCAL_TOOLS_PROFILE
    return boto3.Session(**args)


def get_codeartifact_token():
    ca = get_session().client("codeartifact")
    response = ca.get_authorization_token(
        domain=CODEARTIFACT_DOMAIN, domainOwner=TOOLS_ACCOUNT
    )
    return response["authorizationToken"]


def usage():
    print("usage: get_aws_token.py [service]")
    print("enabled services: codeartifact")
    sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        usage()
    service = sys.argv[1]
    if service == "codeartifact":
        print(get_codeartifact_token())
    else:
        usage()
