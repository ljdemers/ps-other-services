import os
from ssl import CERT_REQUIRED, PROTOCOL_TLSv1_2, SSLContext

from cassandra import ConsistencyLevel
from cassandra.auth import PlainTextAuthProvider
from cassandra.query import dict_factory
from cassandra.cluster import Cluster, ExecutionProfile, EXEC_PROFILE_DEFAULT

from ps_cassandra_ais20.utils.exceptions import CassandraConnectionError
from ps_cassandra_ais20.utils.log_manager import logger

SESSION_CACHE = {}
CONNECTION_KEYSPACE = "keyspace"
CONNECTION_CASSANDRA = "cassandra"


def aws_keyspace_session_factory():
    """
    Helper function that instanciate a new AWS Keyspace connection.
    """
    username = os.environ.get("CASSANDRA_KEYSPACE_USERNAME")
    password = os.environ.get("CASSANDRA_KEYSPACE_PASSWORD")
    cert_path = os.environ.get("CASSANDRA_KEYSPACE_AUTH_CERT_PATH")
    permit_clear_text = \
        os.environ.get("CASSANDRA_PERMIT_CLEAR_TEXT", "false").lower() in ('true', '1')

    if not cert_path and not permit_clear_text:
        raise AssertionError("SSL cert path must be provided when CASSANDRA_PERMIT_CLEAR_TEXT "
                             "is not set (CASSANDRA_KEYSPACE_AUTH_CERT_PATH)")

    options = {}

    # always use local quorum
    profile = ExecutionProfile(
        consistency_level=ConsistencyLevel.LOCAL_QUORUM,
        row_factory=dict_factory
    )
    options["execution_profiles"] = {EXEC_PROFILE_DEFAULT: profile}

    if cert_path:
        # Build path where security certificate lives
        absolute_path = os.path.abspath(__file__)
        certificate = os.path.abspath(os.path.join(absolute_path, "../..", cert_path))

        options["ssl_context"] = SSLContext(PROTOCOL_TLSv1_2)
        options["ssl_context"].load_verify_locations(certificate)
        options["ssl_context"].verify_mode = CERT_REQUIRED

        options["auth_provider"] = PlainTextAuthProvider(username=username, password=password)

    if os.environ.get("CASSANDRA_PORT"):
        options["port"] = int(os.environ.get("CASSANDRA_PORT"))

    try:
        cluster = Cluster(
            [os.environ.get("CASSANDRA_AWS")],
            **options)
    except Exception:
        logger.logger.exception("Connection to Keyspaces was not successful.")
        raise CassandraConnectionError
    session = cluster.connect(os.environ.get("CASSANDRA_KEYSPACE"))

    return session


def cassandra_session_factory():
    """
    Helper function that instanciate a new Cassandra connection.
    """
    try:
        cluster = Cluster(os.environ.get("CASSANDRA_SERVERS").split(","))
    # FIXME limit to cassandra exceptions (and consider just propagating original exception) + typo
    except Exception:
        logger.logger.exception("Connection to Cassandra was not successful.")
        raise CassandraConnectionError
    session = cluster.connect(os.environ.get("CASSANDRA_KEYSPACE"))

    return session


def get_connection(name):
    """
    Get a cassandra connection from the named source.
    Connections are cached to reduce connection overhead.

    Args:
        name (str): name of the connection
    """
    if name not in [CONNECTION_CASSANDRA, CONNECTION_KEYSPACE]:
        raise CassandraConnectionError(f"Invalid connection name: {name}")

    session = SESSION_CACHE.get(name)
    if not session:
        try:
            factory = {
                CONNECTION_KEYSPACE: aws_keyspace_session_factory,
                CONNECTION_CASSANDRA: cassandra_session_factory,
            }[name]
            session = factory()
        except KeyError:
            raise CassandraConnectionError(f"Invalid connection name: {name}")
        SESSION_CACHE[name] = session
    return session


def close_connection(name):
    """
    Close a named connection and remove it from the cache

    Args:
        name (str): name of the connection
    """
    session = SESSION_CACHE.get(name)
    if not session:
        raise CassandraConnectionError(f"Session {name} not found.")
    SESSION_CACHE.pop(name, None)

    session.shutdown()
