class CassandraError(Exception):
    pass


class CassandraConnectionError(CassandraError):
    pass
