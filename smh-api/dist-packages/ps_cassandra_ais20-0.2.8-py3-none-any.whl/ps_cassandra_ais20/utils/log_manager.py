import os
import sys

from loguru import logger as loguru_logger


class Logger:
    def __init__(self):
        self.settings = {"loguru_level": os.environ.get("LOG_LEVEL", "INFO")}
        self._format = (
            "{time} | {level: <8} | {name}:{function}:{line} | {message}{exception}"
        )
        self._logger = loguru_logger

    @property
    def logger(self):
        self._logger.remove()
        self._logger.add(
            sys.stderr, level=self.settings.get("loguru_level"), format=self._format
        )
        return self._logger


logger = Logger()
