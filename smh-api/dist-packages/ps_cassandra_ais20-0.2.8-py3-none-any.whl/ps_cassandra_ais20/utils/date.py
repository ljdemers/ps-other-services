"""
Utility functions for converting dates
"""
import datetime

DATE_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
DATE_FORMAT_FALLBACK = "%Y-%m-%dT%H:%M:%S"


def timestamp2datetime(tstamp):
    """
    Get the datetime for a UTC timestamp
    """
    return datetime.datetime.utcfromtimestamp(tstamp)


def str2date(datestr, date_formats=(DATE_FORMAT, DATE_FORMAT_FALLBACK)):
    """
    Return a utc timezone date from the string
    """
    dt = None
    for date_format in date_formats:
        try:
            dt = datetime.datetime.strptime(datestr, date_format)
        except ValueError:
            pass

    if not dt:
        raise ValueError("Failed to parse date string: %s", datestr)

    return dt.replace(tzinfo=datetime.timezone.utc)


def datetime2timestamp(dt):
    """
    Get the UTC timestamp for the datetime
    """
    dt = dt.replace(tzinfo=datetime.timezone.utc)
    return int(dt.timestamp())


def str2timestamp(strdate):
    """
    Return the timestamp representation of a ISO8601 date representation
    :param strdate: the string representation of the date
    """
    return int(str2date(strdate).timestamp())


def timestamp_from_age(age_in_days: int) -> int:
    """
    Create a datetime used to filter data from an age parameter.

    :param age_in_days: the number of days to subtract from the
    current time.
    """
    dt = datetime.datetime.utcnow()
    dt = dt - datetime.timedelta(days=age_in_days)
    return int(dt.timestamp())
