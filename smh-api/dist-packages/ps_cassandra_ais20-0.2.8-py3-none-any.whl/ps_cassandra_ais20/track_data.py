import os
from operator import itemgetter
from typing import Dict, List

import statsd
from cassandra.query import dict_factory

import ps_cassandra_ais20.utils.connection_manager as cm
from ps_cassandra_ais20.ais20 import AIS20Reader
from ps_cassandra_ais20.utils.date import datetime2timestamp, str2date
from ps_cassandra_ais20.utils.log_manager import logger


def get_complete_track_data(
    mmsi: int, request_dates: Dict, position_count: int,
) -> List:
    """Retrieve trail data from the appropriate data source based on the specific conditions:
    1. end-date > watermark and position_count elements can be fetched from Keyspaces
        all of the data can be fetched from Keyspaces
    2. end-date < watermark
        all of the data can be fetched from Cassandra
    3. end-date > watermark and fewer than position_count elements can be fetched from Keyspaces
        in these cases data from watermark to end-date must be fetched from Keyspaces and
        position_count - positions_retrieved must be fetched from Cassandra backwards from watermark
    4. start-date < watermark and end-date > watermark
        data from start-date to watermark is fetched from Cassandra and data from watermark to end-date is fetched from Keyspaces

    Returns data set sorted by timestamp.

    Args:
        mmsi (int): the MMSI of the vessel
        request_dates (dict): structure that holds start/end date data
        position_count (int): count of positions to return
    """
    stats = statsd.StatsClient(
        host=os.environ.get("STATSD_HOST"),
        port=int(os.environ.get("STATSD_PORT")),
        prefix=os.environ.get("STATSD_PREFIX"),
    )

    with stats.timer("get_complete_track_data.elapsed"):
        keyspace_cut_off_date_str = os.environ.get("KEYSPACE_CUT_OFF_DATE")
        cut_off_datetime = str2date(keyspace_cut_off_date_str)
        ts_cut_off_limit = datetime2timestamp(cut_off_datetime)

        end_date = request_dates.get("end_date", None)
        if end_date:
            end_ts = datetime2timestamp(end_date)

        start_date = request_dates.get("start_date", None)
        if start_date:
            start_ts = datetime2timestamp(start_date)
        else:
            start_ts = None

        results = []
        # end-date > watermark and position_count elements can be fetched from Keyspaces
        if end_ts > ts_cut_off_limit:
            logger.logger.debug(
                f"End date: {end_date} is after the cut off date: {keyspace_cut_off_date_str}. Querying Keyspaces for the track data..."
            )
            ks_session = cm.get_connection(cm.CONNECTION_KEYSPACE)
            ks_reader = AIS20Reader(ks_session)
            ks_rows = ks_reader.get_track(
                mmsi=mmsi, end_date=end_date, position_count=position_count
            )
            # data from start-date to watermark is fetched from Cassandra
            # and data from watermark to end-date is fetched from Keyspaces
            if start_ts and start_ts < ts_cut_off_limit:
                logger.logger.debug(
                    f"Start date: {start_date} is before the cut off date: {keyspace_cut_off_date_str}. Querying Cassandra for the rest of the track data..."
                )
                cass_session = cm.get_connection(cm.CONNECTION_CASSANDRA)
                cass_session.row_factory = dict_factory
                cass_reader = AIS20Reader(cass_session)
                cass_rows = cass_reader.get_track(
                    mmsi=mmsi,
                    end_date=cut_off_datetime,
                    position_count=position_count,
                    start_date=start_date,
                )
                # Add results from the two DBs into result
                results = list(ks_rows) + list(cass_rows)
            else:
                # position_count - positions retrieved must be fetched from Cassandra backwards from watermark
                if len(ks_rows.current_rows) < position_count:
                    logger.logger.debug(
                        f"Number of Keyspaces records: {len(ks_rows.current_rows)} less than the requested: {position_count}. Querying Cassandra for the difference..."
                    )
                    cass_session = cm.get_connection(cm.CONNECTION_CASSANDRA)
                    cass_session.row_factory = dict_factory
                    cass_reader = AIS20Reader(cass_session)
                    positions_left = position_count - len(ks_rows.current_rows)
                    cass_rows = cass_reader.get_track(
                        mmsi=mmsi, end_date=end_date, position_count=positions_left
                    )
                    results = list(ks_rows) + list(cass_rows)
                else:
                    logger.logger.debug(
                        f"Number of Keyspaces records: {len(ks_rows.current_rows)} withing the requested limit: {position_count}."
                    )
                    results = list(ks_rows)
        # all of the data can be fetched from Cassandra
        elif end_ts <= ts_cut_off_limit:
            logger.logger.debug(
                f"End date: {end_date} is before the cut off date: {keyspace_cut_off_date_str}. Querying Cassandra for the track data..."
            )
            session = cm.get_connection(cm.CONNECTION_CASSANDRA)
            session.row_factory = dict_factory
            reader = AIS20Reader(session)
            rows = reader.get_track(
                mmsi=mmsi, end_date=end_date, position_count=position_count
            )
            results = list(rows)

        combined_track_results = sorted(
            results, key=itemgetter("timestamp"), reverse=True
        )
        return combined_track_results
