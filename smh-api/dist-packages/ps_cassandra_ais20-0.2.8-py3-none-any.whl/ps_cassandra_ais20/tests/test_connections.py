import os
from unittest.mock import patch

import ps_cassandra_ais20.utils.connection_manager as cm

settings = {
    "CASSANDRA_KEYSPACE": "aistest",
    "CASSANDRA_SERVERS": "test_cass_server",
}

# TODO Extend test coverage
@patch("ps_cassandra_ais20.utils.connection_manager.Cluster", autospec=True)
@patch.dict("os.environ", settings)
def test_get_connection_cassandra(mock_cluster,):
    cm.get_connection(cm.CONNECTION_CASSANDRA)
    assert cm.CONNECTION_CASSANDRA in cm.SESSION_CACHE.keys()
    assert cm.CONNECTION_KEYSPACE not in cm.SESSION_CACHE.keys()
    mock_cluster.assert_called_once_with([os.environ["CASSANDRA_SERVERS"]])
