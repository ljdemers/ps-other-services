import os
from contextlib import contextmanager
from unittest.mock import patch

from ps_cassandra_ais20.utils.connection_manager import (
    aws_keyspace_session_factory,
    cassandra_session_factory,
)


@contextmanager
def mock_file(filepath, content=""):
    with open(filepath, "w") as f:
        f.write(content)
    yield filepath
    try:
        os.remove(filepath)
    except Exception:
        pass


settings = {
    "CASSANDRA_AWS": "cassandra.us-east-1.com",
    "CASSANDRA_KEYSPACE_AUTH_CERT_PATH": "./test.crt",
    "CASSANDRA_KEYSPACE": "aistest",
    "CASSANDRA_PORT": "1234",
    "CASSANDRA_KEYSPACE_USERNAME": "test_username",
    "CASSANDRA_KEYSPACE_PASSWORD": "password123",
    "CASSANDRA_SERVERS": "test_cass_server",
}


@patch(
    "ps_cassandra_ais20.utils.connection_manager.PlainTextAuthProvider", autospec=True
)
@patch("ps_cassandra_ais20.utils.connection_manager.SSLContext", autospec=True)
@patch(
    "ps_cassandra_ais20.utils.connection_manager.SSLContext.load_verify_locations",
    autospec=True,
)
@patch("ps_cassandra_ais20.utils.connection_manager.Cluster.connect", autospec=True)
@patch("ps_cassandra_ais20.utils.connection_manager.Cluster", autospec=True)
@patch.dict("os.environ", settings)
def test_keyspaces_connection_create(
    mock_cluster,
    mock_cluster_connect,
    mock_ssl_context_verify,
    mock_ssl_context,
    mock_auth_provider,
):

    with mock_file(r"./test.crt"):
        aws_keyspace_session_factory()
        # First test autehntication provider is called with the correct environment variables
        mock_auth_provider.assert_called_once_with(
            username=os.environ["CASSANDRA_KEYSPACE_USERNAME"],
            password=os.environ["CASSANDRA_KEYSPACE_PASSWORD"],
        )

        # Then test if the actual Cluster is called with the correct environment variables
        mock_cluster.assert_called_once_with(
            [os.environ["CASSANDRA_AWS"]],
            ssl_context=mock_ssl_context(),
            auth_provider=mock_auth_provider(
                username=os.environ["CASSANDRA_KEYSPACE_USERNAME"],
                password=os.environ["CASSANDRA_KEYSPACE_PASSWORD"],
            ),
            port=int(os.environ["CASSANDRA_PORT"]),
        )


@patch("ps_cassandra_ais20.utils.connection_manager.Cluster.connect", autospec=True)
@patch("ps_cassandra_ais20.utils.connection_manager.Cluster", autospec=True)
@patch.dict("os.environ", settings)
def test_cassandra_connection_create(
    mock_cluster, mock_cluster_connect,
):
    cassandra_session_factory()
    # Test if the actual Cluster is called with the correct environment variables
    mock_cluster.assert_called_once_with([os.environ["CASSANDRA_SERVERS"]])
    mock_cluster_connect.assert_called_once_with([os.environ["CASSANDRA_KEYSPACE"]])
