import factory
from faker import Faker

from typing import NamedTuple

class FactoryOptions(factory.base.FactoryOptions):

    def _build_default_options(self):

        options = super()._build_default_options()
 
        return [
            *options,
            factory.base.OptionDefault('insertion_statement', None, inherit=True),
        ]

class CassandraModelFactory(factory.Factory):

    class Meta:
        abstract = True

    _options_class = FactoryOptions

    session = None

    @classmethod
    def _build(cls, model_class, *args, **kwargs):
        return model_class(*args, **kwargs)

    @classmethod
    def _create(cls, model_class, *args, **kwargs):

        session = kwargs.pop("session")

        if not session:
            raise AssertionError("session argument must be provided in each call.")

        obj = cls._build(model_class, *args, **kwargs)

        obj_dict = obj._asdict()

        session.execute(cls._meta.insertion_statement, obj_dict)

        return obj



class ShipByNameFactory(CassandraModelFactory):

    class Meta:
        model = NamedTuple("ShipByName", [("name", str), ("mmsi", int)])
        insertion_statement = "INSERT INTO ais20.ship_by_name(name, mmsi) VALUES (%(name)s, %(mmsi)s)"

    name = factory.Faker("lexify", text="ship_???????????")


    @factory.lazy_attribute
    def mmsi(self):

        return {int(string) for string in set(Faker().numerify(text="###"))}
