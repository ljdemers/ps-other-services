import datetime
from datetime import timezone
from unittest.mock import Mock, patch

import pytest
from ps_cassandra_ais20.tests.mocks.mock_track_data import (
    mock_cassanadra_track_data,
    mock_keyspaces_track_data,
)

from ps_cassandra_ais20.ais20 import AIS20Reader
from ps_cassandra_ais20.track_data import get_complete_track_data
from ps_cassandra_ais20.utils.date import datetime2timestamp


class TestReaderDataCollections:
    session = None
    reader = None
    stats = None
    settings = {
        "KEYSPACE_CUT_OFF_DATE": "2021-09-01T00:00:00Z",
        "STATSD_HOST": "localhost",
        "STATSD_PREFIX": "ais_cassandra",
        "STATSD_PORT": "8125",
    }

    @patch.dict("os.environ", settings)
    def setup_method(self, mock_settings):

        self.session = Mock()
        self.reader = AIS20Reader(self.session)
        self.stmt_patcher = patch("ps_cassandra_ais20.ais20.AIS20Reader.get_statement")
        self.mock_stmt = self.stmt_patcher.start()

    def teardown_method(self):
        self.stmt_patcher.stop()

    @patch.dict("os.environ", settings)
    def test_data_collection_with_start_date(self):
        mmsi = 123456789
        start_date = datetime.datetime(2021, 1, 1, tzinfo=timezone.utc)
        end_date = datetime.datetime(2021, 12, 1, tzinfo=timezone.utc)
        position_count = 2
        self.reader.get_track(mmsi, end_date, position_count, start_date)

        self.mock_stmt.assert_called_with(
            "_select_position_by_mmsi_start_end_timestamp"
        )
        self.mock_stmt.return_value.bind.assert_called_with(
            [
                mmsi,
                datetime2timestamp(start_date),
                datetime2timestamp(end_date),
                position_count,
            ]
        )

    @patch.dict("os.environ", settings)
    def test_data_collection_without_start_date(self):
        mmsi = 123456789
        end_date = datetime.datetime(2021, 12, 1, tzinfo=timezone.utc)
        position_count = 2
        self.reader.get_track(mmsi, end_date, position_count)

        self.mock_stmt.assert_called_with("_select_position_by_mmsi_timestamp")
        self.mock_stmt.return_value.bind.assert_called_with(
            [mmsi, datetime2timestamp(end_date), position_count]
        )


class TestGetTrackDataCollections:
    settings = {
        "KEYSPACE_CUT_OFF_DATE": "2022-02-04T00:00:00Z",
        "CASSANDRA_KEYSPACE": "aistest",
        # "CASSANDRA_PORT": "1234",
        # "CASSANDRA_KEYSPACE_USERNAME": "test_username",
        # "CASSANDRA_KEYSPACE_PASSWORD": "password123",
        "CASSANDRA_SERVERS": "test_cass_server,",
        "STATSD_HOST": "localhost",
        "STATSD_PREFIX": "ais_cassandra",
        "STATSD_PORT": "8125",
    }

    @patch("ps_cassandra_ais20.utils.connection_manager.Cluster.connect", autospec=True)
    @patch("ps_cassandra_ais20.utils.connection_manager.Cluster", autospec=True)
    # @patch("track_data.AIS20Reader")
    # @patch("track_data.get_complete_track_data")
    @patch("ps_cassandra_ais20.ais20.AIS20Reader")
    @patch.dict("os.environ", settings)
    @pytest.mark.skip("Update test once SMH and AISAPI is confirmed to be woking ok")
    def test_get_track_data_from_keyspaces_and_cassandra(
        self, mock_reader, mock_cluster, mock_cluster_connect,
    ):
        mmsi = 123456789
        position_count = 100
        request_dates = {
            "end_date": datetime.datetime(2022, 2, 1, tzinfo=timezone.utc),
        }

        # mock_track_data.get_complete_track_data.return_value.ks_reader.get_track.return_value = mock_keyspaces_track_data.get("data")
        # mock_track_data.get_complete_track_data.return_value.cass_reader.get_track.return_value = mock_cassanadra_track_data.get("data")
        ks_reader = mock_reader.return_value
        ks_reader.get_track.return_value = mock_keyspaces_track_data.get("data")

        cass_reader = mock_reader.return_value
        cass_reader.get_track.return_value = mock_cassanadra_track_data.get("data")

        resp = get_complete_track_data(
            mmsi=mmsi, request_dates=request_dates, position_count=position_count
        )
        print(resp.count)
