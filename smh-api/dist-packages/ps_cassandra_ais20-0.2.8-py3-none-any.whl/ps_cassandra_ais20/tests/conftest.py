import os

import pytest
from cassandra.query import dict_factory

from ps_cassandra_ais20.utils.connection_manager import cassandra_session_factory, aws_keyspace_session_factory

# FIXME better way to load? This repo as source of schema?
SCHEMA_PATH = "/opt/ais20/schema.cql"

def generic_session(factory):

    session = factory()

    assert session

    check_empty(session)

    apply_schema(session)

    # FIXME contraversal?
    session.row_factory = dict_factory

    yield session

    wipe_casssandra(session)


@pytest.fixture 
def cassandra_session_vanilla():

    yield from generic_session(cassandra_session_factory)

@pytest.fixture 
def cassandra_session_aws():

    yield from generic_session(aws_keyspace_session_factory)

def check_empty(session):
    
    keyspaces = session.execute("SELECT * FROM system_schema.keyspaces;")

    for keyspace in keyspaces:

        if "system" in keyspace.keyspace_name:
            continue

        raise AssertionError(f"Found an existing keyspace: {keyspace.keyspace_name}. If using docker tests try running the down command.")


def apply_schema(session):

    assert os.path.exists(SCHEMA_PATH)

    with open(SCHEMA_PATH) as infile:

        statements = infile.read().split(";")

        for statement in statements:
            statement = statement.strip()
            if statement:
                session.execute(statement)


def wipe_casssandra(session):

    # FIXME check result
    session.execute("DROP KEYSPACE ais20;")
