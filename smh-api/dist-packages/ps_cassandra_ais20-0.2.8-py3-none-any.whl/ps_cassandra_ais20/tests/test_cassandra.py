import pytest

from ps_cassandra_ais20.utils.connection_manager import cassandra_session_factory

from ps_cassandra_ais20.tests.factories import ShipByNameFactory

def test_cassandra(cassandra_session_vanilla, cassandra_session_aws):

    pass

def test_cassandra_add_data(cassandra_session_vanilla, cassandra_session_aws):

    vanilla_ships = ShipByNameFactory.create_batch(10, session=cassandra_session_vanilla)

    queried_vanilla_ships = cassandra_session_vanilla.execute("select * from ais20.ship_by_name").all()

    assert len(queried_vanilla_ships) == 10

    # Find matching name
    found_name = False
    for queried_ship in queried_vanilla_ships:

        if vanilla_ships[0].name == queried_ship["name"]:
            found_name = True
            assert vanilla_ships[0].mmsi == set(queried_ship["mmsi"])

    assert found_name, "Couldn't find ship in queried results"

    # Check other cassandra

    aws_ships = ShipByNameFactory.create_batch(5, session=cassandra_session_aws)

    queried_aws_ships = cassandra_session_aws.execute("select * from ais20.ship_by_name").all()

    assert len(queried_aws_ships) == 5
