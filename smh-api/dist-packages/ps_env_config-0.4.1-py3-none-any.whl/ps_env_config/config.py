"""
Manage fetching configuration from the environment.  The following values
are expected to be provided by the environment or the defaults below.

A configuration item is defined by a set of lines an all caps and underscore
name followed by either mandatory or a default value.
"""
import os
import re
import logging
import sys
import boto3

CONFIG_ITEMS = dict()
VERSION = None
ENVFILE_PATH = '/etc/profile.d/environment'


def find_in_system_path(filename):
    """
    Locate the specified filename by searching all of the
    directories on sys.path
    """
    for dirname in sys.path:
        candidate = os.path.join(dirname, filename)
        logging.debug('looking for %s file at %s', filename, candidate)
        if os.path.isfile(candidate):
            logging.info('%s found.', candidate)
            return candidate


def get_version():
    """
    Find the version file on the path
    """
    global VERSION

    if not VERSION:
        versionfile_path = find_in_system_path('VERSION')
        with open(versionfile_path) as versionfile:
            VERSION = versionfile.read().rstrip()

    return VERSION


def load_ssm_parameters(ssm_parameter_path, ssm=None):
    """
    Load parameters from the specified path into the environment
    """
    if ssm is None:
        region = os.environ.get('AWSREGION')
        if not region:
            region = "us-east-1"
        session = boto3.Session(region_name=region)
        ssm = session.client("ssm")

    try:
        response = ssm.get_parameters_by_path(Path=ssm_parameter_path, Recursive=True)
        print('fetched parameters: ', response)
        for parameter in response['Parameters']:
            name = parameter['Name']
            name = name.replace(ssm_parameter_path, '')
            value = parameter['Value']
            os.environ[name] = value
    except:
        logging.error("failed to load parameters from SSM")


def load_config_items():
    """Parse the configuration readme file for configured values"""
    pat = re.compile(r'^- ([A-Z_]*)\s(mandatory|default)\s*(\S*)$')
    configfile_path = find_in_system_path('config.md')

    if os.path.exists(ENVFILE_PATH):
        with open(ENVFILE_PATH) as envfile:
            for line in envfile.readlines():
                try:
                    # skip blank lines and comments
                    if not line.strip():
                        continue
                    if line.strip().startswith('#'):
                        continue
                    key, val = line.rstrip().split('=')
                    os.environ[key] = val
                except:
                    logging.error('invalid line in environment file: %s', line)
    else:
        logging.warn(
            'no environment file to parse at: {0}'.format(ENVFILE_PATH)
        )

    assert os.path.exists(configfile_path), 'no configfile found!'
    with open(configfile_path) as configfile:
        config = configfile.readlines()
    for line in config:
        match = pat.match(line)
        mandatory = None
        if match:
            key = match.groups()[0]
            if match.groups()[1] == 'mandatory':
                mandatory = True
                default = None
            if match.groups()[1] == 'default':
                mandatory = False
                default = match.groups()[2]
            CONFIG_ITEMS[key] = {'mandatory': mandatory, 'default': default}


def get(key):
    """Get a configured value"""
    if key == 'VERSION':
        return get_version()

    if len(CONFIG_ITEMS) == 0:
        load_config_items()

    if key not in CONFIG_ITEMS:
        raise KeyError('not a config item: {0}; available: {1}'.format(
                       key, ','.join(CONFIG_ITEMS.keys())))

    item = CONFIG_ITEMS[key]
    val = os.environ.get(key, item['default'])
    if item['mandatory'] and not val:
        raise ValueError('%s is not defined but is mandatory' % key)

    return val
