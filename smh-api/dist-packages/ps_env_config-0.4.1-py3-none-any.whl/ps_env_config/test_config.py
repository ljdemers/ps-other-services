import unittest
from unittest import mock
import os
import boto3
from botocore.stub import Stubber
from dateutil.tz import tzlocal
import datetime

from ps_env_config import config


TEST_CONFIG = """
- SERVICE_SCHEME default https

    The scheme with which to communicate with the service.

- SERVICE_HOST mandatory

    The hostname of the service.

- ENVIRONMENT default foo

    The execution environment for the service.

- FOOSERVICE_DB_ENGINE mandatory

    The DB engine, e.g. postgresql
"""
TEST_VERSION = '1.2.111'
TEST_ENVFILE = """
# comments are nice
ENVIRONMENT=development
"""
TEST_SSM_RESPONSE={
    'Parameters': [
        {'Name': '/test/fooservice/3/FOOSERVICE_DB_ENGINE', 'Type': 'String', 'Value': 'foo', 'Version': 1, 'LastModifiedDate': datetime.datetime(2020, 9, 15, 16, 45, 54, 623000, tzinfo=tzlocal()), 'ARN': 'arn:aws:ssm:us-east-1:324252367609:parameter/test/commservice/3/COMMSERVICE_DB_ENGINE', 'DataType': 'text'}, 
        {'Name': '/test/fooservice/3/FOOSERVICE_DB_ENGINE', 'Type': 'String', 'Value': 'bar', 'Version': 1, 'LastModifiedDate': datetime.datetime(2020, 9, 15, 16, 45, 53, 381000, tzinfo=tzlocal()), 'ARN': 'arn:aws:ssm:us-east-1:324252367609:parameter/test/commservice/3/COMMSERVICE_DB_HOST', 'DataType': 'text'}, 
        {'Name': '/test/fooservice/3/FOOSERVICE_DB_ENGINE', 'Type': 'String', 'Value': 'baz', 'Version': 2, 'LastModifiedDate': datetime.datetime(2020, 9, 15, 17, 22, 43, 870000, tzinfo=tzlocal()), 'ARN': 'arn:aws:ssm:us-east-1:324252367609:parameter/test/commservice/3/COMMSERVICE_DB_USER', 'DataType': 'text'}
        ], 
    'ResponseMetadata': {
        'RequestId': 'e37978e9-1ca1-40bf-9eeb-4049829e7669', 'HTTPStatusCode': 200, 'HTTPHeaders': {'server': 'Server', 'date': 'Fri, 25 Sep 2020 17:55:43 GMT', 'content-type': 'application/x-amz-json-1.1', 'content-length': '762', 'connection': 'keep-alive', 'x-amzn-requestid': 'e37978e9-1ca1-40bf-9eeb-4049829e7669'}, 'RetryAttempts': 0
        }
}

class ConfigTest(unittest.TestCase):
    _config_path = 'config.md'
    _version_path = 'VERSION'
    _envfile_path = 'environment'

    def setUp(self):
        """
        Create VERSION and config.md files
        """
        with open(self._config_path, 'w') as configfile:
            configfile.write(TEST_CONFIG)
        with open(self._version_path, 'w') as versionfile:
            versionfile.write(TEST_VERSION)
        with open(self._envfile_path, 'w') as envfile:
            envfile.write(TEST_ENVFILE)

        config.ENVFILE_PATH = self._envfile_path

    def tearDown(self):
        """
        Delete VERSION and config.md files
        """
        os.unlink(self._config_path)
        os.unlink(self._version_path)
        os.unlink(self._envfile_path)

    def test_version(self):
        self.assertEqual(TEST_VERSION, config.get('VERSION'))

    def test_unspecified(self):
        self.assertRaises(KeyError, config.get, 'some other key')

    def test_default(self):
        self.assertEqual('https', config.get('SERVICE_SCHEME'))

    @mock.patch.dict('os.environ', {'SERVICE_SCHEME': 'http'})
    def test_override_default(self):
        self.assertEqual('http', config.get('SERVICE_SCHEME'))

    def test_mandatory_raises(self):
        self.assertRaises(ValueError, config.get, 'SERVICE_HOST')

    @mock.patch.dict('os.environ', {'SERVICE_HOST': 'localhost'})
    def test_mandatory(self):
        self.assertEqual('localhost', config.get('SERVICE_HOST'))

    def test_envfile(self):
        self.assertEqual("development", config.get('ENVIRONMENT'))

    @mock.patch('boto3.session')
    def test_ssm(self, session):
        session = boto3.Session()
        ssm = session.client("ssm")
        with Stubber(ssm) as stubber:
            expected_parameters = {'Path': '/test/fooservice/3/', 'Recursive': True}
            stubber.add_response('get_parameters_by_path', 
                                TEST_SSM_RESPONSE, 
                                expected_parameters)

            config.load_ssm_parameters('/test/fooservice/3/', ssm)
            actual = config.get('FOOSERVICE_DB_ENGINE')
            expected = 'baz'
            self.assertEqual(expected, actual)

if __name__ == '__main__':
    unittest.main()
